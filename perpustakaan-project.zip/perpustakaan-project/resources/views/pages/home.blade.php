@extends('layouts.app')

@section('title')
    Home
@endsection

@section('body')
    <h1>Home</h1>
@endsection