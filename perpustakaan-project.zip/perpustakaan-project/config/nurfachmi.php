<?php

return [
    /**
     * Application's version
     */
    'version' => '1.0.0',
];